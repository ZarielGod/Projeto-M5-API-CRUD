# TGM5

Esse trabalho em grupo é um Crud simples aonde você pode adicionar, editar ou excluir joias que estão localizadas em um banco de dados MSQL. <br />
Como o arquivo do Crud é uma pasta que vai além dos 25MB que o git aceita você pode encontra-lo neste link ( https://drive.google.com/drive/folders/12Q4CfAkGQXKYAdWl9x3mF07eHPe_bvTe?usp=sharing )

Pessoas do grupo responsavéis pelo backend :

º Letícia Moretti <br />
º Patryck Campos <br />
º Maria Fernanda <br />

Pessoas do grupo responsavéis pelo frontend:

º Larissa Belem <br />
º Léticia Moretti <br />
º Daniel Dias<br />
